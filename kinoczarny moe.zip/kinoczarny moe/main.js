document.getElementById('sprawdz-cene').addEventListener('click', function() {
    const checkbox = document.querySelectorAll('.miejsce-checkbox:checked');
    const liczbaBiletów = checkbox.length;
    const cenaBiletu = 20;
    const całkowitaCena = liczbaBiletów * cenaBiletu;
    const cena = document.getElementById('cena');

    if (liczbaBiletów > 0) {

        let wybraneMiejsca = '';

        for (let i = 0; i < checkbox.length; i++) {
            wybraneMiejsca += checkbox[i].nextElementSibling.innerText + ' ';
        }

        cena.innerHTML = `Łączna cena biletów: ${całkowitaCena} zł <br> Wybrane Miejsca: ${wybraneMiejsca}`;
    } else {
        cena.innerText = 'Nie wybrano żadnych miejsc.';
    }
});